/* 1.Base class initialization in c++
   2. Pure Virtual 
   3. Dyanamic binding
   4.  */

#include<iostream>
#include<math.h>
using namespace std;

class Shape {

    int id;
    public:

    Shape(int id){
        this -> id = id;
    }
    //virtual void area () = 0;
    /*If not to make it abstract class, we can do it by
        virtal void area() {
            return ;
        } 
    */

    /*Pure virtual function can be overloaded*/
    virtual int area(int) {
        return this->id;
    }
};

class Rectangle : public Shape {

    int len, bre;
    public: 
    Rectangle(int id, int len, int bre) : Shape(id){
        this -> len = len;
        this -> bre = bre;
    }

    void area() {
        cout <<"Area of rectangle :"<< len*bre <<endl;
    }

}; 

class Circle : public Rectangle {
    
    int radius;
    public:
    Circle (int id, int len, int bre, int r) : Rectangle(id ,len, bre){
        radius = r;
    }  

    void area () {
        cout<<"Area of Circle :"<<3.14*pow(radius,2)<<endl;
    }

};

int main() {
    /*Object on heap*/
    Shape s1(4);
    cout<<s1.area(1)<<endl;

    /*Object on Stack*/
    Circle s2(4,2,3,1);
    s2.area();

    Rectangle* s3 = new Rectangle(4,5,6); /*We can print area function of rectangle class*/
    s3->area();

    Shape* s4 = new Rectangle(4,5,6);
        /*Main point is, we can store any class object on a polymorphic class, 
        which is shape here*/

}