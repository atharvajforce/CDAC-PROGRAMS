#include<iostream>
using namespace std;

int main() {
    int l,b;

    cout<<"Enter length and breadth: \n";
    cin>>l>>b;

    cout<<"area of the rectangle:"<< l*b;
}