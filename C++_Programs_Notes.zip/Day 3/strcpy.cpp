#include<iostream>
#include<string.h>
using namespace std;
int main()
{

    char str1[] ="Hello";
    char str2[50];

    strcpy(str2 ,str1);
    cout<<str2;
}

